"""Observe the normal embedded player; no hard-coded source keys or DRM bypass."""
from __future__ import annotations

import asyncio
import contextlib
import html
from dataclasses import dataclass
from urllib.parse import urlsplit

from aiohttp import web
from playwright.async_api import async_playwright


class ResolveError(RuntimeError):
    pass


def embed_url(mal_id: int, language: str, episode: int) -> str:
    if mal_id < 1 or episode < 1 or language not in {"dub", "sub"}:
        raise ValueError("Use positive MAL/episode numbers and dub or sub.")
    return f"https://megaplay.buzz/stream/mal/{mal_id}/{episode}/{language}"


def choose_caption(tracks: list[dict]) -> dict | None:
    captions = [t for t in tracks if t.get("kind") in {"captions", "subtitles"}
                and urlsplit(str(t.get("file", ""))).scheme == "https"]
    english = [t for t in captions if "english" in t.get("label", "").lower()
               or t.get("srclang", "").lower() in {"en", "eng"}]
    return next((t for t in english if t.get("default")), None) or (english[0] if english else None)


@dataclass
class Stream:
    url: str
    headers: dict[str, str]
    tracks: list[dict]
    context: object

    async def caption_bytes(self, track: dict) -> bytes:
        response = await self.context.request.get(
            track["file"], headers={"Referer": "https://megaplay.buzz/"}, timeout=30000)
        if not response.ok:
            raise ResolveError(f"Subtitle server returned HTTP {response.status}.")
        data = await response.body()
        if len(data) > 10 * 1024 * 1024 or not data.lstrip().startswith(b"WEBVTT"):
            raise ResolveError("The subtitle response is not a supported WebVTT file.")
        return data


class Resolver:
    def __init__(self, timeout: float = 60, headless: bool = True):
        self.timeout = timeout
        self.headless = headless
        self.runner = self.browser = self.playwright = None

    async def __aenter__(self):
        app = web.Application()

        async def player(request):
            try:
                url = embed_url(int(request.query["mal"]), request.query["lang"],
                                int(request.query["ep"]))
            except (KeyError, ValueError):
                raise web.HTTPBadRequest()
            return web.Response(content_type="text/html", text=(
                '<!doctype html><html><body style="margin:0;background:#000">'
                f'<iframe src="{html.escape(url, quote=True)}" width="1280" height="720" '
                'allow="autoplay; fullscreen" referrerpolicy="strict-origin-when-cross-origin" '
                'style="border:0"></iframe></body></html>'))

        app.router.add_get("/", player)
        try:
            self.runner = web.AppRunner(app)
            await self.runner.setup()
            site = web.TCPSite(self.runner, "127.0.0.1", 0)
            await site.start()
            self.origin = f"http://127.0.0.1:{self.runner.addresses[0][1]}"
            self.playwright = await async_playwright().start()
            self.browser = await self.playwright.chromium.launch(headless=self.headless)
            return self
        except BaseException:
            await self.__aexit__(None, None, None)
            raise

    async def __aexit__(self, *_):
        if self.browser:
            await self.browser.close()
        if self.playwright:
            await self.playwright.stop()
        if self.runner:
            await self.runner.cleanup()

    @contextlib.asynccontextmanager
    async def resolve(self, mal_id: int, language: str, episode: int):
        """Keep the isolated player context alive until the download finishes."""
        embed_url(mal_id, language, episode)
        context = await self.browser.new_context(viewport={"width": 1280, "height": 720})
        page = await context.new_page()
        tracks: list[dict] = []
        found = asyncio.get_running_loop().create_future()
        tasks = set()
        source_status = []

        async def inspect(response):
            try:
                parsed = urlsplit(response.url)
                if parsed.hostname == "megaplay.buzz" and "getSources" in parsed.path:
                    source_status.append(response.status)
                    if response.ok:
                        payload = await response.json()
                        if isinstance(payload, dict):
                            tracks.extend(t for t in payload.get("tracks", []) if isinstance(t, dict))
                # Only player-frame traffic, never top-level ads or popup media.
                frame_url = response.request.frame.url
                if not frame_url.startswith("https://megaplay.buzz/stream/"):
                    return
                if parsed.scheme != "https" or not response.ok:
                    return
                content_type = response.headers.get("content-type", "").lower()
                if ".m3u8" not in parsed.path.lower() and "mpegurl" not in content_type:
                    return
                body = await response.text()
                if body.lstrip().startswith("#EXTM3U") and not found.done():
                    request_headers = await response.request.all_headers()
                    headers = {k: v for k, v in request_headers.items()
                               if k.lower() in {"user-agent", "referer", "origin"}}
                    found.set_result((response.url, headers))
            except Exception:
                # Other responses may be opaque or disappear during context shutdown.
                pass

        def observed(response):
            task = asyncio.create_task(inspect(response))
            tasks.add(task)
            task.add_done_callback(tasks.discard)

        async def dismiss_popup(popup):
            with contextlib.suppress(Exception):
                await popup.close()

        async def activate():
            while not found.done():
                for frame in page.frames:
                    if frame.url.startswith("https://megaplay.buzz/stream/"):
                        with contextlib.suppress(Exception):
                            await frame.locator('.jw-icon-display, .jw-display-icon-container').first.click(timeout=700)
                await asyncio.sleep(2)

        page.on("response", observed)
        page.on("popup", dismiss_popup)
        clicker = None
        try:
            await page.goto(f"{self.origin}/?mal={mal_id}&lang={language}&ep={episode}",
                            wait_until="domcontentloaded", timeout=30000)
            clicker = asyncio.create_task(activate())
            try:
                url, headers = await asyncio.wait_for(found, self.timeout)
            except asyncio.TimeoutError:
                statuses = ", ".join(map(str, source_status)) or "no source response"
                raise ResolveError(
                    f"No playable HLS stream within {self.timeout:g}s ({statuses}). "
                    "Episode/language may be unavailable, unmapped, or blocked by the provider.") from None
            # The source JSON precedes HLS; drain any still-running response handlers.
            if tasks:
                await asyncio.wait(list(tasks), timeout=2)
            yield Stream(url, headers, list(tracks), context)
        finally:
            if clicker:
                clicker.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await clicker
            for task in list(tasks):
                task.cancel()
            if tasks:
                await asyncio.gather(*list(tasks), return_exceptions=True)
            await context.close()
