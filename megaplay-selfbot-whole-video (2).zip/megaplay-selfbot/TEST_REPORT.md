# Verification — whole-video edition

Date: 14 October 2026

## Complete live episode download: PASSED

Episode 25 was selected randomly from episodes 1–30 of **One Piece**, MAL ID **21**, **dub**. The full episode was downloaded and decoded successfully. After adding explicit MP4-container normalization, the same episode was downloaded again through the final pipeline and revalidated.

Final-pipeline command:

```text
python test_live_download.py 21 dub --episode 25
```

| Check | Result |
|---|---|
| Complete HLS download | Passed; no sample or duration cut was requested |
| Final whole MP4 size | **243,086,080 bytes** — 243.09 decimal MB |
| Container | Real MP4 (`mov,mp4,m4a,3gp,3g2,mj2`) |
| Video | H.264, 1440 × 1080 |
| Audio | AAC, stereo |
| Full playlist duration | 1477.979 seconds |
| Downloaded-file duration | 1477.976489 seconds — approximately **24:38** |
| Playlist/file duration difference | Approximately 0.0025 seconds |
| Full-file FFmpeg decode | **Passed**, exit code 0, using `-xerror` |
| Whole-file SHA-256 | `04035bac6660e56f1e0abdb091b60875492448a43562de2b67507411a7a0a63d` |
| Splitting | None |
| Discord upload | **Not tested** |

The initial raw HLS download occupied 253,769,920 bytes. The final losslessly remuxed MP4 is smaller because transport/container overhead and non-media data streams are removed; the full video and audio remain, with matching duration. No truncation or video re-encoding was used for this dub test.

The temporary downloaded episode was removed after validation. The package contains code and test evidence, not the episode itself. `LIVE_DOWNLOAD_REPORT.json` records the final test's machine-readable measurements, timestamps and hash.

## Anime-title lookup: PASSED

A live AniList lookup using MAL ID 21 returned the series name. The resulting caption was:

```text
One Piece | episode : 12
```

The Jikan fallback was not live-verified successfully in this environment; its direct request timed out. The primary AniList path succeeded. Local title overrides are covered by an automated test.

## Automated tests: 25 PASSED

```text
python -m pytest -q
25 passed
```

Covered:

- Valid/invalid episode ranges and MAL embed endpoint construction.
- English caption selection.
- Resume persistence and account/channel/language scoping; corrupt-state handling.
- Legacy multipart checkpoints not counting as completed whole-video uploads.
- Command registration and ignoring commands from other accounts.
- Synthetic media generation and probing.
- Actual `yt-dlp` download of locally generated HLS, normalization to real MP4, caption burning, subtitle muxing and no-caption mode.
- No non-media data streams in final synthetic MP4 outputs.
- Exact anime-name/episode message captions and one attachment per successful episode.
- Sequential mocked uploads, resume and temporary-file cleanup.
- Source failure limits and not checkpointing failed episodes.
- Oversized whole videos rejected before any upload, with no splitting.
- Default 1,000,000,000-byte configured cap, not clamped to a guild's smaller inferred limit.
- Local anime-title overrides and title validation.
- Process timeout, cancellation and child-process reaping.

Source files also passed Python bytecode compilation.

Environment: Python 3.13, `discord.py-self` 2.1.0, Playwright Chromium, `yt-dlp` 2026.8.19 and FFmpeg on Linux.

## Not tested / not guaranteed

- **No Discord account login or real upload was performed.** No account token was requested or used.
- The claimed 1 GB account entitlement is **not verified**. The code defaults to that requested cap, but Discord enforces its own actual limit.
- Every episode in a range, other languages' full live downloads, provider availability from your network or long-term player/CDN compatibility.
- Full live subtitle burning on a complete anime episode; this was tested on synthetic media.
- Windows execution; setup instructions are provided, but execution tests were on Linux.

A successful full-episode source test does not guarantee all episodes or Discord uploads will work. See README.md for setup, account risks and failure handling.
