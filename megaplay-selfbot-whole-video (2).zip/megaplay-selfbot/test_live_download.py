"""Explicit full-episode download test. No Discord token or uploads.
Run only for content you are authorized to download. The media is deleted after
validation; a JSON report is retained. This file is not a pytest test module.
"""
import argparse
import asyncio
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import random
import re
import tempfile
from urllib.parse import urljoin

from dotenv import load_dotenv
from media import download, probe, run_process
from resolver import Resolver

ROOT = Path(__file__).resolve().parent


async def manifest_duration(stream):
    url = stream.url
    for _ in range(4):
        response = await stream.context.request.get(url, headers=stream.headers, timeout=30000)
        if not response.ok:
            return None
        text = await response.text()
        durations = re.findall(r'^#EXTINF:([0-9.]+)', text, re.MULTILINE)
        if durations:
            return sum(map(float, durations))
        lines = text.splitlines()
        for index, line in enumerate(lines):
            if line.startswith('#EXT-X-STREAM-INF:'):
                candidate = next((line.strip() for line in lines[index+1:] if line.strip() and not line.startswith('#')), None)
                if candidate:
                    url = urljoin(url, candidate)
                    break
        else:
            return None
    return None


async def main(args):
    load_dotenv(ROOT / '.env')
    episode = args.episode if args.episode is not None else random.SystemRandom().randint(1, 30)
    report = {
        'started_utc': datetime.now(timezone.utc).isoformat(),
        'mal_id': args.mal_id, 'language': args.language, 'episode': episode,
        'selection': 'explicit' if args.episode is not None else 'random episode from 1 through 30',
        'discord_upload_tested': False, 'media_retained': False,
    }
    print(f'Full download test: MAL {args.mal_id}, {args.language}, episode {episode} ({report["selection"]})', flush=True)
    report_path = ROOT / 'LIVE_DOWNLOAD_REPORT.json'
    try:
        with tempfile.TemporaryDirectory(prefix='megaplay-full-test-', dir=ROOT) as folder:
            work = Path(folder)
            async with Resolver(90) as resolver:
                async with resolver.resolve(args.mal_id, args.language, episode) as stream:
                    report['manifest_duration_seconds'] = await manifest_duration(stream)
                    print('Stream resolved; downloading the COMPLETE episode (not a sample).', flush=True)
                    video, note = await download(stream, work, args.language, quality=720, subtitle_mode='burn', timeout=3600)
            info = await probe(video)
            report['file_size_bytes'] = video.stat().st_size
            report['container_format'] = info['format']['format_name']
            if 'mp4' not in report['container_format'].split(','):
                raise RuntimeError('Downloaded file is not a real MP4 container.')
            report['duration_seconds'] = float(info['format']['duration'])
            report['streams'] = [{key: stream[key] for key in ('codec_type','codec_name','width','height','channels') if key in stream}
                                 for stream in info['streams']]
            with video.open('rb') as file:
                report['sha256'] = hashlib.file_digest(file, 'sha256').hexdigest()
            report['subtitle_note'] = note
            expected = report['manifest_duration_seconds']
            if expected is not None and abs(report['duration_seconds'] - expected) > 3:
                raise RuntimeError('Downloaded duration differs from complete media playlist duration by over three seconds.')
            print(f"Downloaded {report['file_size_bytes']:,} bytes; duration {report['duration_seconds']:.3f}s. Decoding the ENTIRE file to check integrity.", flush=True)
            await run_process(['ffmpeg','-nostdin','-hide_banner','-loglevel','error','-xerror',
                               '-i',str(video),'-map','0:v:0','-map','0:a:0?','-f','null','-'],
                              work,timeout=1800)
            report['full_ffmpeg_decode'] = 'passed'
            report['result'] = 'passed'
    except Exception as exc:
        report['result'] = 'failed'
        report['error'] = f'{type(exc).__name__}: {exc}'
        raise
    finally:
        report['finished_utc'] = datetime.now(timezone.utc).isoformat()
        report_path.write_text(json.dumps(report, indent=2) + '\n')
        print(json.dumps(report, indent=2), flush=True)
        print('Temporary episode file removed. Report:', report_path, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mal_id', nargs='?', type=int, default=21)
    parser.add_argument('language', nargs='?', choices=['dub','sub'], default='dub')
    parser.add_argument('--episode', type=int)
    asyncio.run(main(parser.parse_args()))
