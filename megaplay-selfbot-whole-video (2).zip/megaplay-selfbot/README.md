# MegaPlay → Discord: whole-episode uploader

Uses `discord.py-self` with the requested commands:

```text
.download 21 dub 1 100
.download 21 sub 1 100
```

`21` is the MyAnimeList ID; `1 100` is an **inclusive** episode range. Episodes are downloaded and uploaded sequentially. Each successful episode is **one whole MP4 attachment in one message**, with this caption:

```text
One Piece | episode : 12
```

**There is no video splitting or numbered-parts mode.** The configured cap defaults to **1 GB (1,000,000,000 bytes)**, as requested. This does not grant an entitlement or override Discord's actual server-side limit for your account.

> Discord prohibits selfbots and says automating normal user accounts can result in account termination. An official bot account is the compliant alternative. [1](https://support.discord.com/hc/en-us/articles/115002192352-Automated-User-Accounts-Self-Bots)
>
> Download and repost only media you own or have permission to distribute. Keep your account token local; never share it in chat or commit it.

## What changed

- Removed the splitter, part filenames, part counters and `MAX_PARTS` setting.
- Added `UPLOAD_LIMIT_MB=1000` for the requested 1 GB whole-file cap; the previous `UPLOAD_LIMIT_MIB` setting is no longer used.
- Added anime title lookup through AniList, with Jikan as a fallback and optional local title overrides.
- Upload caption format is exactly `Anime Name | episode : NUMBER`.
- HLS downloads are explicitly remuxed into a real fast-start MP4, not simply given an `.mp4` extension. Non-video/audio/subtitle data streams are discarded.
- A full live episode download and full-file FFmpeg decode are documented in `TEST_REPORT.md` and `LIVE_DOWNLOAD_REPORT.json`.

## Setup

Requirements: Python **3.11+**, FFmpeg and ffprobe on `PATH`, Playwright Chromium, and sufficient temporary disk space. Caption burning requires FFmpeg with libass and libx264. Tests were run on Python 3.13/Linux.

Do not install regular `discord.py`, `py-cord`, or another `discord` package into the same virtual environment.

### Debian / Ubuntu

```bash
sudo apt-get update
sudo apt-get install -y python3-venv ffmpeg
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m playwright install --with-deps chromium
cp .env.example .env
chmod 600 .env
```

Edit `.env` locally:

```dotenv
DISCORD_TOKEN=your_account_token
CHANNEL_ID=0
UPLOAD_LIMIT_MB=1000
```

Then:

```bash
python bot.py
```

Keep the terminal running. From the same Discord account, type `.download 21 dub 1 100` in the destination channel.

### Windows PowerShell

Install Python and a full FFmpeg build; ensure `ffmpeg -version` and `ffprobe -version` both work in a new terminal.

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m playwright install chromium
Copy-Item .env.example .env
notepad .env
.\.venv\Scripts\python.exe bot.py
```

### Upgrading the previous package

Replace the source files. In your existing `.env`, remove `UPLOAD_LIMIT_MIB` and `MAX_PARTS`, and add:

```dotenv
UPLOAD_LIMIT_MB=1000
```

Keep your private token and `CHANNEL_ID`. Do not run two instances against one `state.json`. Old checkpoints containing multiple message IDs are not treated as completed whole-video uploads; those episodes will be resent as single attachments. Old single-attachment checkpoints still count as completed. To resend regardless, use the optional `force` argument.

## Commands

| Command | Behavior |
|---|---|
| `.download 21 dub 1 100` | Dubbed episodes 1–100, one whole video per message |
| `.download 21 sub 1 100` | Subbed episodes, same ordering |
| `.download 21 dub 1 100 force` | Resend even if recorded as completed |
| `.status` | Current/last job, episode, phase and counters |
| `.cancel` | Cancel current job and clean temporary files |
| `.mphelp` | Show command help |

Only messages from your own account are accepted. One job runs at a time; additional jobs are rejected, not queued. Uploads go to the command channel unless `CHANNEL_ID` is configured. The destination must support attachments and your account must have permission to send them.

## Anime names

The MAL ID is looked up once per job, not once per episode. The title provider's English title is preferred, with romanized/original title as a fallback. Example:

```text
One Piece | episode : 25
```

If both title services fail, the job stops before downloading rather than silently uploading messages with the wrong name. To customize a title or avoid network lookup, copy `title_overrides.example.json` to `title_overrides.json` and enter MAL-ID-to-title mappings:

```json
{
  "21": "One Piece"
}
```

Mention suppression is enabled even if a title contains mention-like text.

## Configuration

| Variable | Default | Meaning |
|---|---:|---|
| `CHANNEL_ID` | `0` | Command channel; positive ID fixes the upload destination |
| `UPLOAD_LIMIT_MB` | `1000` | Whole-video cap in decimal MB, not MiB |
| `QUALITY` | `720` | Preferred maximum height; fallback to best available if no matching format exists |
| `SUBTITLE_MODE` | `burn` | For `sub`: `burn`, `mux`, or `none` |
| `HEADLESS` | `true` | `false` opens visible Chromium for desktop troubleshooting |
| `RESOLVE_TIMEOUT` | `60` | Seconds to wait for player HLS resolution |
| `OPERATION_TIMEOUT` | `3600` | Timeout per download/remux/encode operation |
| `MAX_TEMP_GIB` | `8` | Temporary episode workspace budget, including intermediates |
| `MAX_EPISODES` | `500` | Maximum inclusive range length per command |
| `UPLOAD_DELAY` | `3` | Minimum delay between episode uploads; channel slowmode can increase it |
| `EPISODE_ATTEMPTS` | `2` | Fresh resolve/download attempts per episode |
| `MAX_CONSECUTIVE_FAILURES` | `3` | Stop after this many consecutive source/media failures |

Restart after editing `.env`.

### One whole video — no splitting

The final MP4's measured size must be at most `UPLOAD_LIMIT_MB × 1,000,000`. Files above that cap are not uploaded: the job stops with their size and the configured cap. The bot does not split, truncate or automatically compress a video to fit.

Discord remains authoritative. If it returns HTTP 413 or another upload error, the job stops and that episode is not marked complete. Actual account entitlements are not detected or verified. Changing this setting does not increase Discord's real limit.

`QUALITY` selects an available stream format; it does not resize video. If a source offers only 1080p, it can fall back to 1080p even with `QUALITY=720`.

### Subtitles

For `sub`, an advertised English caption track is used:

- `burn`: re-encode with visible captions, including in Discord; CPU-intensive.
- `mux`: embed a selectable track, faster, but Discord may not display it; use VLC or another supporting player after download.
- `none`: do not add external captions.

If no English track is advertised, a warning is sent to the command channel and the original video is used; captions may already be hardcoded or may be unavailable. Video-message captions retain the exact anime-name/episode format. `dub` does not add external captions. The script does not translate captions.

### Resume and cleanup

After Discord accepts the single whole-video attachment, its message ID is saved atomically to `state.json`. Rerun the command to skip those completed episodes. Source/download failures are retried; isolated failures are skipped, and three consecutive failures stop the job by default.

Temporary media is deleted after each completed/failed/cancelled episode. Sent messages are never deleted by the bot. A crash between Discord accepting a message and local checkpointing can still cause a duplicate on resume. Resume does not check whether messages have since been deleted; use `force` to resend.

## Tests without a Discord token

Quick manifest-only check:

```bash
python check_source.py 21 dub 1
```

Full live download, playlist-duration comparison, actual MP4-container verification and full-file FFmpeg decode:

```bash
python test_live_download.py 21 dub --episode 25
```

Omit `--episode` to randomly choose an episode from 1–30. Only use this random mode for titles that have those episodes. The test downloads a full episode, validates it, deletes the temporary media and writes `LIVE_DOWNLOAD_REPORT.json`. It does **not** upload to Discord or need your account token.

Local unit/integration tests:

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q
```

These use synthetic media and mocked Discord transport. They do not log into Discord or download anime.

## Integration and troubleshooting

The [MegaPlay documentation](https://megaplay.buzz/api) defines an embed endpoint, not a direct documented MP4 download API:

```text
https://megaplay.buzz/stream/mal/{mal-id}/{ep-num}/{sub-or-dub}
```

An isolated Playwright browser loads a private loopback page with that iframe and observes successful HLS responses from the player frame. The player's normal code handles its source payload. Fresh URLs and media request headers are passed to `yt-dlp`. No hard-coded source decryption keys, third-party extraction proxy, CAPTCHA bypass or DRM bypass is included. The browser never receives your Discord token.

- **Missing Chromium or Linux libraries:** rerun `python -m playwright install --with-deps chromium`.
- **Title lookup fails:** retry later or set `title_overrides.json`.
- **No HLS stream:** check episode/language availability and MAL mapping. Not every requested episode is available. Provider access blocks are not bypassed.
- **Source 403:** signed URLs may expire or your IP may be rejected. A retry resolves a fresh URL, but access restrictions may persist.
- **Subtitle burn fails:** check that FFmpeg has the `subtitles` filter. `SUBTITLE_MODE=mux` avoids burning but may not display in Discord.
- **Oversized video:** choose an available lower-quality format or change the configured cap only if your account really supports it. This version never falls back to parts.
- **Disk/timeout failure:** free space or adjust `MAX_TEMP_GIB` / `OPERATION_TIMEOUT`. Media copies during remuxing/burning also need space.

Logs are under `logs/`. Media error logs can contain temporary signed source URLs; treat logs as private and redact before sharing. `.env`, temporary media, logs, local title overrides and resume history are excluded by `.gitignore`.
