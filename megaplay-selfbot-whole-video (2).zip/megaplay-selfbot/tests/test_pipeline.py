from contextlib import asynccontextmanager
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock

from aiohttp import web
import pytest

import bot as module
from bot import Job, MegaPlayBot, Settings, State
from media import download, probe, run_process
from resolver import Stream


@pytest.mark.asyncio
@pytest.mark.parametrize('mode', ['burn', 'mux', 'none'])
async def test_download_and_subtitles_with_local_synthetic_video(tmp_path, mode):
    fixture=tmp_path/'fixture'; fixture.mkdir()
    video=fixture/'input.mp4'
    await run_process([
        'ffmpeg','-nostdin','-hide_banner','-loglevel','error','-y',
        '-f','lavfi','-i','testsrc2=size=320x240:rate=24',
        '-f','lavfi','-i','sine=frequency=440:sample_rate=44100',
        '-t','2','-c:v','libx264','-preset','ultrafast','-c:a','aac',str(video)
    ], fixture,timeout=30)
    # Test the HLS downloader against locally generated, non-copyrighted media.
    await run_process([
        'ffmpeg','-nostdin','-hide_banner','-loglevel','error','-y','-i',str(video),
        '-c','copy','-hls_time','1','-hls_list_size','0',str(fixture/'index.m3u8')
    ],fixture,timeout=30)
    app=web.Application();app.router.add_static('/',fixture)
    runner=web.AppRunner(app);await runner.setup()
    site=web.TCPSite(runner,'127.0.0.1',0);await site.start()
    port=runner.addresses[0][1]
    async def body(): return b'WEBVTT\n\n00:00:00.000 --> 00:00:01.500\nSynthetic test caption\n'
    request=SimpleNamespace(get=AsyncMock(return_value=SimpleNamespace(ok=True,body=body)))
    context=SimpleNamespace(cookies=AsyncMock(return_value=[]),request=request)
    stream=Stream(f'http://127.0.0.1:{port}/index.m3u8',{},[
        {'kind':'captions','label':'English','file':'https://example.com/sub.vtt'}
    ],context)
    try:
        output,note=await download(stream,tmp_path/'work','sub',subtitle_mode=mode,timeout=60)
        info=await probe(output)
        assert output.exists() and note is None
        assert 'mp4' in info['format']['format_name'].split(',')
        assert all(stream['codec_type'] != 'data' for stream in info['streams'])
        assert float(info['format']['duration'])>=1.9
        assert not (tmp_path/'work'/'cookies.txt').exists()
        if mode=='mux':
            assert any(s['codec_type']=='subtitle' for s in info['streams'])
        if mode=='burn':
            assert output.name=='episode.mp4'
            assert not any(s['codec_type']=='subtitle' for s in info['streams'])
    finally:
        await runner.cleanup()


class FakeResolver:
    def __init__(self,*args): pass
    async def __aenter__(self): return self
    async def __aexit__(self,*args): pass
    @asynccontextmanager
    async def resolve(self,mal,language,episode):
        yield SimpleNamespace(episode=episode)


@pytest.mark.asyncio
async def test_job_order_and_completed_episode_resume(tmp_path, monkeypatch):
    monkeypatch.setattr(module,'ROOT',tmp_path)
    monkeypatch.setattr(module,'Resolver',FakeResolver)
    monkeypatch.setattr(module,'fetch_anime_title',AsyncMock(return_value='One Piece'))
    downloaded=[]
    async def fake_download(stream,work,language,**kwargs):
        downloaded.append(stream.episode)
        file=work/'episode.mp4';file.write_bytes(b'synthetic fixture')
        return file,None
    monkeypatch.setattr(module,'download',fake_download)
    client=MegaPlayBot(Settings(delay=0),State(tmp_path/'state.json'))
    client._connection.user=SimpleNamespace(id=123)
    ctx=SimpleNamespace(send=AsyncMock())
    target=SimpleNamespace(id=456,send=AsyncMock(return_value=SimpleNamespace(id=987)))
    job=Job(21,'dub',1,3,456)
    await client.run_job(ctx,target,job,1_000_000,False)
    assert downloaded==[1,2,3]
    captions=[call.args[0] for call in target.send.await_args_list]
    assert captions == [f'One Piece | episode : {i}' for i in range(1,4)]
    assert all('file' in call.kwargs and 'files' not in call.kwargs for call in target.send.await_args_list)
    assert job.sent==3 and job.phase=='finished'
    job2=Job(21,'dub',1,3,456)
    await client.run_job(ctx,target,job2,1_000_000,False)
    assert downloaded==[1,2,3]
    assert job2.sent==0 and job2.skipped==3
    assert list((tmp_path/'downloads').iterdir())==[]


@pytest.mark.asyncio
async def test_failed_episode_not_checkpointed(tmp_path, monkeypatch):
    monkeypatch.setattr(module,'ROOT',tmp_path)
    monkeypatch.setattr(module,'Resolver',FakeResolver)
    monkeypatch.setattr(module,'fetch_anime_title',AsyncMock(return_value='One Piece'))
    monkeypatch.setattr(module,'download',AsyncMock(side_effect=RuntimeError('Synthetic unavailable episode')))
    client=MegaPlayBot(Settings(delay=0,attempts=1,max_consecutive_failures=2),State(tmp_path/'state.json'))
    client._connection.user=SimpleNamespace(id=123)
    ctx=SimpleNamespace(send=AsyncMock())
    target=SimpleNamespace(id=456,send=AsyncMock())
    job=Job(21,'dub',1,10,456)
    await client.run_job(ctx,target,job,1_000_000,False)
    assert job.failed==2 and job.current==2 and job.sent==0
    assert client.state.data=={}
    target.send.assert_not_awaited()
