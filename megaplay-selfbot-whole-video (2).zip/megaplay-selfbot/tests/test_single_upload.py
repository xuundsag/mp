import json
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest

import bot as module
from bot import Job, MegaPlayBot, Settings, State
from metadata import TitleError, clean_title, episode_caption, fetch_anime_title
from test_pipeline import FakeResolver


def test_default_one_gb_cap(monkeypatch):
    monkeypatch.delenv('UPLOAD_LIMIT_MB', raising=False)
    assert Settings.from_env().upload_mb * 1_000_000 == 1_000_000_000
    monkeypatch.setenv('UPLOAD_LIMIT_MB', '500')
    assert Settings.from_env().upload_mb == 500


def test_title_and_exact_caption():
    assert episode_caption('One Piece', 12) == 'One Piece | episode : 12'
    assert clean_title('ONE PIECE') == 'One Piece'
    assert clean_title('FLCL') == 'FLCL'
    assert clean_title('Some\nAnime  Name') == 'Some Anime Name'
    with pytest.raises(TitleError): clean_title('  ')


@pytest.mark.asyncio
async def test_title_override_without_network(tmp_path):
    file=tmp_path/'title_overrides.json'
    file.write_text(json.dumps({'21':'One Piece'}))
    assert await fetch_anime_title(21,file) == 'One Piece'


@pytest.mark.asyncio
async def test_command_uses_account_cap_not_guild_cap(tmp_path):
    client=MegaPlayBot(Settings(), State(tmp_path/'state.json'))
    guild=SimpleNamespace(filesize_limit=10*1024**2,me=None)
    channel=SimpleNamespace(id=456,guild=guild,send=AsyncMock())
    ctx=SimpleNamespace(channel=channel,send=AsyncMock())
    client.run_job=AsyncMock()
    await client.download_command(ctx,21,'dub',1,3)
    await client.worker
    assert client.run_job.await_args.args[3] == 1_000_000_000


@pytest.mark.asyncio
async def test_oversized_video_never_split_or_uploaded(tmp_path, monkeypatch):
    monkeypatch.setattr(module,'ROOT',tmp_path)
    monkeypatch.setattr(module,'Resolver',FakeResolver)
    monkeypatch.setattr(module,'fetch_anime_title',AsyncMock(return_value='One Piece'))
    async def fake_download(stream,work,language,**kwargs):
        file=work/'episode.mp4';file.write_bytes(b'0123456789')
        return file,None
    monkeypatch.setattr(module,'download',fake_download)
    client=MegaPlayBot(Settings(delay=0),State(tmp_path/'state.json'))
    client._connection.user=SimpleNamespace(id=123)
    ctx=SimpleNamespace(send=AsyncMock())
    target=SimpleNamespace(id=456,send=AsyncMock())
    job=Job(21,'dub',1,3,456)
    await client.run_job(ctx,target,job,9,False)
    target.send.assert_not_awaited()
    assert job.failed==1 and job.sent==0 and job.current==1
    assert job.phase=='stopped: whole episode exceeds upload cap'
    assert client.state.data=={}
    assert any('no splitting performed' in call.args[0] for call in ctx.send.await_args_list)
    assert list((tmp_path/'downloads').iterdir())==[]


def test_legacy_multipart_state_is_not_treated_as_whole_video(tmp_path):
    state=State(tmp_path/'state.json')
    key=state.key(1,2,21,'dub',25)
    state.mark(key,[101,102])
    assert not state.completed(key)
    state.mark(key,[103])
    assert state.completed(key)
