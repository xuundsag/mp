import asyncio
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest
from discord.ext import commands

from bot import MegaPlayBot, Settings, State, validate_request
from resolver import choose_caption, embed_url
from media import MediaError, UploadTooLarge, check_upload_size, probe, run_process


@pytest.mark.parametrize("mal,lang,start,end", [(0,"dub",1,2),(21,"raw",1,2),(21,"sub",0,2),(21,"dub",3,2),(21,"dub",1,501)])
def test_bad_ranges(mal,lang,start,end):
    with pytest.raises(commands.BadArgument):
        validate_request(mal,lang,start,end,500)


def test_range_and_endpoint():
    validate_request(21,"dub",1,100,500)
    assert embed_url(21,"sub",100) == "https://megaplay.buzz/stream/mal/21/100/sub"
    with pytest.raises(ValueError):
        embed_url(-1,"dub",1)


def test_captions():
    english={"file":"https://example.com/en.vtt","kind":"captions","label":"English","default":True}
    spanish={"file":"https://example.com/es.vtt","kind":"captions","label":"Spanish"}
    assert choose_caption([spanish,english]) == english
    assert choose_caption([spanish]) is None
    assert choose_caption([{**english,"file":"file:///etc/passwd"}]) is None


def test_state_persists_and_is_scoped(tmp_path):
    state=State(tmp_path/"state.json")
    key=state.key(1,2,21,"dub",1)
    state.mark(key,[55])
    other=State(tmp_path/"state.json")
    assert other.completed(key)
    assert not other.completed(other.key(1,3,21,"dub",1))
    assert not other.completed(other.key(2,2,21,"dub",1))
    assert not other.completed(other.key(1,2,21,"sub",1))
    assert other.data[key]["message_ids"] == [55]


def test_corrupted_state_is_not_silently_reset(tmp_path):
    path=tmp_path/"state.json"; path.write_text("not JSON")
    with pytest.raises(ValueError): State(path)


def test_command_registration(tmp_path):
    bot=MegaPlayBot(Settings(), State(tmp_path/"state.json"))
    assert set(c.name for c in bot.commands) == {"download","status","cancel","mphelp"}
    assert list(bot.get_command("download").clean_params) == ["mal_id","language","start","end","mode"]


@pytest.mark.asyncio
async def test_owner_filter(tmp_path):
    bot=MegaPlayBot(Settings(),State(tmp_path/"state.json"))
    bot._connection.user=SimpleNamespace(id=123)
    bot.process_commands=AsyncMock()
    await bot.on_message(SimpleNamespace(author=SimpleNamespace(id=456)))
    bot.process_commands.assert_not_awaited()
    own=SimpleNamespace(author=SimpleNamespace(id=123))
    await bot.on_message(own)
    bot.process_commands.assert_awaited_once_with(own)


@pytest.mark.asyncio
async def test_synthetic_video_probe(tmp_path):
    video=tmp_path/"synthetic.mp4"
    await run_process([
        "ffmpeg","-nostdin","-hide_banner","-loglevel","error","-y",
        "-f","lavfi","-i","testsrc2=size=640x360:rate=24",
        "-f","lavfi","-i","sine=frequency=440:sample_rate=44100",
        "-t","12","-c:v","libx264","-preset","ultrafast","-g","24",
        "-keyint_min","24","-sc_threshold","0","-b:v","1500k","-c:a","aac",str(video)
    ],tmp_path,timeout=60)
    assert float((await probe(video))["format"]["duration"]) >= 11.9
    assert check_upload_size(video, video.stat().st_size) == video
    with pytest.raises(UploadTooLarge, match="No file uploaded and no splitting"):
        check_upload_size(video, video.stat().st_size - 1)
    assert not (tmp_path / 'parts').exists()


@pytest.mark.asyncio
async def test_subprocess_cancel_reaps(tmp_path):
    import sys
    pidfile=tmp_path/"pid.txt"
    task=asyncio.create_task(run_process([
        sys.executable,"-c",
        "import os,time,pathlib; pathlib.Path('pid.txt').write_text(str(os.getpid())); time.sleep(60)"
    ],tmp_path))
    for _ in range(100):
        if pidfile.exists(): break
        await asyncio.sleep(0.02)
    assert pidfile.exists()
    pid=int(pidfile.read_text())
    task.cancel()
    with pytest.raises(asyncio.CancelledError): await task
    if Path('/proc').exists():
        assert not Path(f'/proc/{pid}').exists()


@pytest.mark.asyncio
async def test_timeout(tmp_path):
    import sys
    with pytest.raises(MediaError,match="timed out"):
        await run_process([sys.executable,"-c","import time;time.sleep(20)"],tmp_path,timeout=.1)
