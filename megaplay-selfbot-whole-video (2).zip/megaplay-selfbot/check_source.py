"""Verify player resolution without a Discord token or downloading an episode."""
import argparse
import asyncio
import json
from urllib.parse import urlsplit

from dotenv import load_dotenv
from bot import ROOT, Settings
from resolver import Resolver, choose_caption


async def check(args):
    load_dotenv(ROOT / ".env")
    settings = Settings.from_env()
    async with Resolver(settings.resolve_timeout, settings.headless) as resolver:
        async with resolver.resolve(args.mal_id, args.language, args.episode) as stream:
            track = choose_caption(stream.tracks)
            print(json.dumps({
                "status": "playable HLS manifest observed",
                "mal_id": args.mal_id,
                "episode": args.episode,
                "language": args.language,
                "stream_host": urlsplit(stream.url).hostname,
                "english_caption": track.get("label") if track else None,
                "notice": "No episode downloaded or sent. Signed stream URL deliberately omitted."
            }, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mal_id", type=int)
    parser.add_argument("language", choices=["dub", "sub"])
    parser.add_argument("episode", type=int)
    asyncio.run(check(parser.parse_args()))
