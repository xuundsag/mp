from __future__ import annotations

import asyncio
import contextlib
import json
import shutil
import sys
from pathlib import Path

from resolver import Stream, choose_caption


class MediaError(RuntimeError):
    pass


async def run_process(args: list[str], cwd: Path, *, timeout: float = 3600,
                      max_bytes: int = 8 * 1024**3) -> str:
    """No shell. Kill/reap subprocesses on timeout, disk exhaustion or cancellation."""
    log = cwd / "process.log"
    with log.open("ab") as output:
        process = await asyncio.create_subprocess_exec(
            *args, cwd=str(cwd), stdout=output, stderr=asyncio.subprocess.STDOUT)
        waiter = asyncio.create_task(process.wait())
        deadline = asyncio.get_running_loop().time() + timeout
        try:
            while not waiter.done():
                if asyncio.get_running_loop().time() >= deadline:
                    raise MediaError("Media operation timed out.")
                usage = sum(p.stat().st_size for p in cwd.rglob("*") if p.is_file())
                if usage > max_bytes or shutil.disk_usage(cwd).free < 256 * 1024**2:
                    raise MediaError("Temporary-storage budget exceeded or disk nearly full.")
                await asyncio.wait({waiter}, timeout=2)
            if waiter.result() != 0:
                raise MediaError(f"{Path(args[0]).name} failed; inspect the local process log.")
        finally:
            if process.returncode is None:
                with contextlib.suppress(ProcessLookupError):
                    process.terminate()
                try:
                    await asyncio.wait_for(asyncio.shield(waiter), 5)
                except asyncio.TimeoutError:
                    with contextlib.suppress(ProcessLookupError):
                        process.kill()
                    await waiter
            if not waiter.done():
                await waiter
    # Read only a bounded tail, not an entire noisy subprocess log.
    with log.open("rb") as fp:
        fp.seek(max(0, log.stat().st_size - 16000))
        return fp.read().decode("utf-8", "replace")


async def probe(path: Path) -> dict:
    process = await asyncio.create_subprocess_exec(
        "ffprobe", "-v", "error", "-show_format", "-show_streams", "-of", "json", str(path),
        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
    try:
        stdout, _ = await asyncio.wait_for(process.communicate(), 30)
        if process.returncode:
            raise MediaError("FFprobe could not read the downloaded video.")
        result = json.loads(stdout)
        if not any(s.get("codec_type") == "video" for s in result.get("streams", [])):
            raise MediaError("Download contains no video stream.")
        if float(result["format"].get("duration", 0)) <= 0:
            raise MediaError("Downloaded video has no valid duration.")
        return result
    finally:
        if process.returncode is None:
            with contextlib.suppress(ProcessLookupError):
                process.kill()
            await process.communicate()


async def download(stream: Stream, work: Path, language: str, *, quality: int = 720,
                   subtitle_mode: str = "burn", max_bytes: int = 8 * 1024**3,
                   timeout: int = 3600) -> tuple[Path, str | None]:
    work.mkdir(parents=True, exist_ok=True)
    if shutil.disk_usage(work).free < 512 * 1024**2:
        raise MediaError("At least 512 MiB of free disk space is required.")
    cookie_file = work / "cookies.txt"
    lines = ["# Netscape HTTP Cookie File"]
    for cookie in await stream.context.cookies():
        lines.append("\t".join([cookie["domain"], str(cookie["domain"].startswith(".")).upper(),
                                cookie["path"], str(cookie["secure"]).upper(),
                                str(max(0, int(cookie.get("expires", 0)))),
                                cookie["name"], cookie["value"]]))
    cookie_file.write_text("\n".join(lines) + "\n", encoding="utf-8")
    cookie_file.chmod(0o600)
    args = [sys.executable, "-m", "yt_dlp", "--ignore-config", "--no-playlist", "--no-progress",
            "--no-warnings", "--socket-timeout", "30", "--retries", "3", "--fragment-retries", "3",
            "--abort-on-unavailable-fragments", "--concurrent-fragments", "1",
            "--cookies", str(cookie_file), "--hls-use-mpegts", "--remux-video", "mp4",
            "--merge-output-format", "mp4", "--max-filesize", str(max_bytes // 2),
            "-f", f"bv*[height<={quality}]+ba/b[height<={quality}]/b",
            "-o", str(work / "source.%(ext)s")]
    for key, value in stream.headers.items():
        args += ["--add-header", f"{key}:{value}"]
    args += ["--", stream.url]
    try:
        await run_process(args, work, timeout=timeout, max_bytes=max_bytes)
    finally:
        cookie_file.unlink(missing_ok=True)
    source = work / "source.mp4"
    if not source.exists() or not source.stat().st_size:
        raise MediaError("Downloader did not produce source.mp4 (possibly over the disk-size limit).")
    await probe(source)
    # Native HLS may leave MPEG-TS bytes under an .mp4 filename, particularly
    # with --hls-use-mpegts. Always create a real, fast-start MP4 and discard
    # non-media data streams (for example timed ID3) before Discord upload.
    normalized = work / "whole.mp4"
    await run_process([
        "ffmpeg", "-nostdin", "-hide_banner", "-loglevel", "warning", "-y", "-i", str(source),
        "-map", "0:v:0", "-map", "0:a:0?", "-map", "0:s?",
        "-c:v", "copy", "-c:a", "copy", "-c:s", "mov_text",
        "-movflags", "+faststart", str(normalized)
    ], work, timeout=timeout, max_bytes=max_bytes)
    normalized_info = await probe(normalized)
    if "mp4" not in normalized_info["format"].get("format_name", "").split(","):
        raise MediaError("Final video is not a real MP4 container.")
    source.unlink()
    source = normalized
    note = None
    if language == "sub" and subtitle_mode != "none":
        track = choose_caption(stream.tracks)
        if track is None:
            note = "No external English caption track was advertised; subtitles may be hardcoded or unavailable."
        else:
            subtitle = work / "subtitles.vtt"
            subtitle.write_bytes(await stream.caption_bytes(track))
            result = work / "episode.mp4"
            args = ["ffmpeg", "-nostdin", "-hide_banner", "-loglevel", "warning", "-y", "-i", str(source)]
            if subtitle_mode == "burn":
                args += ["-map", "0:v:0", "-map", "0:a:0?", "-vf", "subtitles=subtitles.vtt",
                         "-c:v", "libx264", "-preset", "veryfast", "-crf", "22", "-pix_fmt", "yuv420p",
                         "-c:a", "aac", "-b:a", "128k"]
            elif subtitle_mode == "mux":
                args += ["-i", str(subtitle), "-map", "0:v:0", "-map", "0:a:0?", "-map", "1:0",
                         "-c:v", "copy", "-c:a", "copy", "-c:s", "mov_text",
                         "-metadata:s:s:0", "language=eng", "-disposition:s:0", "default"]
            else:
                raise ValueError("SUBTITLE_MODE must be burn, mux or none.")
            args += ["-movflags", "+faststart", str(result)]
            await run_process(args, work, timeout=timeout, max_bytes=max_bytes)
            await probe(result)
            source.unlink()
            source = result
    return source, note


class UploadTooLarge(MediaError):
    pass


def check_upload_size(source: Path, limit: int) -> Path:
    """Require one whole MP4; never split, truncate or silently compress it."""
    if limit < 1:
        raise ValueError("Upload limit must be positive.")
    size = source.stat().st_size
    if size > limit:
        raise UploadTooLarge(
            f"Whole episode is {size / 1_000_000:.1f} MB; configured cap is "
            f"{limit / 1_000_000:.1f} MB. No file uploaded and no splitting performed.")
    return source
