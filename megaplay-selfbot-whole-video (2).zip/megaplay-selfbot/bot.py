from __future__ import annotations

import asyncio
import contextlib
import json
import logging
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path
import shutil
import tempfile
from dataclasses import dataclass

import discord
from discord.ext import commands
from dotenv import load_dotenv

from media import UploadTooLarge, check_upload_size, download
from metadata import TitleError, episode_caption, fetch_anime_title
from resolver import Resolver

ROOT = Path(__file__).resolve().parent
log = logging.getLogger("megaplay")
MIB = 1024**2


def integer_env(name: str, default: int, low: int, high: int) -> int:
    try:
        value = int(os.getenv(name, str(default)))
    except ValueError:
        raise ValueError(f"{name} must be an integer.") from None
    if not low <= value <= high:
        raise ValueError(f"{name} must be between {low} and {high}.")
    return value


@dataclass
class Settings:
    channel_id: int = 0
    upload_mb: int = 1000
    quality: int = 720
    subtitle_mode: str = "burn"
    max_episodes: int = 500
    max_temp_bytes: int = 8 * 1024**3
    operation_timeout: int = 3600
    resolve_timeout: int = 60
    delay: int = 3
    attempts: int = 2
    max_consecutive_failures: int = 3
    headless: bool = True

    @classmethod
    def from_env(cls):
        subtitle_mode = os.getenv("SUBTITLE_MODE", "burn").lower()
        if subtitle_mode not in {"burn", "mux", "none"}:
            raise ValueError("SUBTITLE_MODE must be burn, mux or none.")
        return cls(
            channel_id=integer_env("CHANNEL_ID", 0, 0, 2**64 - 1),
            upload_mb=integer_env("UPLOAD_LIMIT_MB", 1000, 1, 2000),
            quality=integer_env("QUALITY", 720, 144, 2160),
            subtitle_mode=subtitle_mode,
            max_episodes=integer_env("MAX_EPISODES", 500, 1, 10000),
            max_temp_bytes=integer_env("MAX_TEMP_GIB", 8, 1, 1000) * 1024**3,
            operation_timeout=integer_env("OPERATION_TIMEOUT", 3600, 60, 86400),
            resolve_timeout=integer_env("RESOLVE_TIMEOUT", 60, 10, 300),
            delay=integer_env("UPLOAD_DELAY", 3, 1, 300),
            attempts=integer_env("EPISODE_ATTEMPTS", 2, 1, 5),
            max_consecutive_failures=integer_env("MAX_CONSECUTIVE_FAILURES", 3, 1, 1000),
            headless=os.getenv("HEADLESS", "true").lower() not in {"0", "false", "no"},
        )


def validate_request(mal: int, language: str, start: int, end: int, maximum: int):
    if mal < 1 or start < 1 or end < start:
        raise commands.BadArgument("MAL ID and episodes must be positive; END must be >= START.")
    if language not in {"dub", "sub"}:
        raise commands.BadArgument("Choose dub or sub (not the literal text dub/sub).")
    if end - start + 1 > maximum:
        raise commands.BadArgument(f"At most {maximum} episodes per job.")


class State:
    def __init__(self, path: Path):
        self.path = path
        # Fail visibly rather than silently losing resume history if corrupted.
        self.data = json.loads(path.read_text()) if path.exists() else {}
        if not isinstance(self.data, dict):
            raise ValueError("Invalid state.json; restore a backup or rename it to start fresh.")

    @staticmethod
    def key(account, channel, mal, language, episode):
        return f"{account}:{channel}:{mal}:{language}:{episode}"

    def completed(self, key: str) -> bool:
        entry = self.data.get(key)
        # Old multipart checkpoints must not suppress the requested whole-video upload.
        return isinstance(entry, dict) and len(entry.get("message_ids", [])) == 1

    def mark(self, key: str, message_ids: list[int]):
        self.data[key] = {"message_ids": message_ids}
        temp = self.path.with_suffix(".tmp")
        temp.write_text(json.dumps(self.data, indent=2), encoding="utf-8")
        temp.replace(self.path)


@dataclass
class Job:
    mal: int
    language: str
    start: int
    end: int
    channel_id: int
    title: str = ""
    current: int = 0
    phase: str = "starting"
    sent: int = 0
    skipped: int = 0
    failed: int = 0

    def text(self):
        return (f"{self.title or f'MAL {self.mal}'} / {self.language.upper()} / episodes {self.start}–{self.end}\n"
                f"Episode: {self.current or '—'} · {self.phase}\n"
                f"Completed: {self.sent} · Already sent: {self.skipped} · Failed: {self.failed}\n"
                f"Destination: <#{self.channel_id}>")


class MegaPlayBot(commands.Bot):
    def __init__(self, settings: Settings, state: State):
        super().__init__(command_prefix=".", self_bot=True, help_command=None,
                         allowed_mentions=discord.AllowedMentions.none())
        self.cfg = settings
        self.state = state
        self.job: Job | None = None
        self.worker: asyncio.Task | None = None
        @self.command(name="download", ignore_extra=False)
        async def download_entry(ctx, mal_id: int, language: str, start: int, end: int, mode: str = "resume"):
            await self.download_command(ctx, mal_id, language, start, end, mode)

        @self.command(name="status", ignore_extra=False)
        async def status_entry(ctx):
            await self.status_command(ctx)

        @self.command(name="cancel", ignore_extra=False)
        async def cancel_entry(ctx):
            await self.cancel_command(ctx)

        @self.command(name="mphelp", ignore_extra=False)
        async def help_entry(ctx):
            await self.help_command_impl(ctx)

    async def on_ready(self):
        log.info("Logged in as %s (%s)", self.user, self.user.id)
        print(f"Ready as {self.user}. Type .mphelp in Discord.")

    async def on_message(self, message):
        # Double-check self_bot ownership: never accept commands from another account.
        if self.user and message.author.id == self.user.id:
            await self.process_commands(message)

    async def on_command_error(self, ctx, error):
        if isinstance(error, commands.CommandNotFound):
            return
        if isinstance(error, commands.UserInputError):
            await ctx.send(f"{error}\nUsage: `.download MAL_ID dub|sub START END [resume|force]`")
        else:
            log.error("Command failed", exc_info=(type(error), error, error.__traceback__))
            await ctx.send("Command failed. Check logs/bot.log; no token or source URLs are posted here.")

    async def help_command_impl(self, ctx):
        await ctx.send(
            "**MegaPlay downloader**\n"
            "`.download 21 dub 1 100` — inclusive episode range, sequential uploads\n"
            "`.download 21 sub 1 100` — subbed episodes (English captions burned in by default)\n"
            "`.download 21 dub 1 100 force` — resend completed episodes\n"
            "`.status` — current/last job\n`.cancel` — stop the current job\n"
            "Uploads go to this channel unless CHANNEL_ID is configured. "
            "One whole video per message; no splitting. Captions include the anime name and episode. "
            "Only your own commands are accepted.")

    async def status_command(self, ctx):
        await ctx.send(self.job.text() if self.job else "No job has run in this session.")

    async def cancel_command(self, ctx):
        if self.worker and not self.worker.done():
            self.worker.cancel()
            await ctx.send("Cancellation requested. Any files already sent remain in the channel.")
        else:
            await ctx.send("No active download job.")

    async def download_command(self, ctx, mal_id: int, language: str, start: int, end: int,
                               mode: str = "resume"):
        language, mode = language.lower(), mode.lower()
        validate_request(mal_id, language, start, end, self.cfg.max_episodes)
        if mode not in {"resume", "force"}:
            raise commands.BadArgument("Optional final argument must be resume or force.")
        if self.worker and not self.worker.done():
            await ctx.send("A job is already running. Use `.status` or `.cancel` first.")
            return
        target = ctx.channel
        if self.cfg.channel_id:
            target = self.get_channel(self.cfg.channel_id) or await self.fetch_channel(self.cfg.channel_id)
        if not hasattr(target, "send"):
            raise commands.BadArgument("Destination must be a text channel, thread or DM that supports attachments.")
        if getattr(target, "guild", None):
            member = target.guild.me
            if member is not None:
                permissions = target.permissions_for(member)
                can_send = (permissions.send_messages_in_threads if isinstance(target, discord.Thread)
                            else permissions.send_messages)
                if not (permissions.view_channel and can_send and permissions.attach_files):
                    raise commands.BadArgument("Missing View Channel, Send Messages or Attach Files permission.")
        # Honor the user's configured account limit; Discord remains authoritative.
        # Decimal MB: default 1000 MB = 1,000,000,000 bytes (1 GB), not 1 GiB.
        limit = self.cfg.upload_mb * 1_000_000
        # No awaits between the busy check and assigning the task after target resolution.
        if self.worker and not self.worker.done():
            await ctx.send("Another job started while resolving the destination. Use `.status`.")
            return
        self.job = Job(mal_id, language, start, end, target.id)
        self.worker = asyncio.create_task(self.run_job(ctx, target, self.job, limit, mode == "force"))

    async def run_job(self, ctx, target, job: Job, limit: int, force: bool):
        cfg = self.cfg
        failures_in_a_row = 0
        try:
            job.phase = "looking up anime name"
            job.title = await fetch_anime_title(job.mal, ROOT / "title_overrides.json")
            await ctx.send(f"Starting {job.title} ({job.language}), episodes {job.start}–{job.end}, "
                           f"in <#{target.id}>. One whole video per message; cap: {limit / 1_000_000:.0f} MB. "
                           "Use `.status` or `.cancel`.")
            (ROOT / "downloads").mkdir(exist_ok=True)
            async with Resolver(cfg.resolve_timeout, cfg.headless) as resolver:
                for episode in range(job.start, job.end + 1):
                    job.current = episode
                    key = self.state.key(self.user.id, target.id, job.mal, job.language, episode)
                    if not force and self.state.completed(key):
                        job.skipped += 1
                        continue
                    with tempfile.TemporaryDirectory(prefix=f"{job.mal}-{episode}-", dir=ROOT / "downloads") as directory:
                        work = Path(directory)
                        try:
                            source = note = None
                            # Only resolution/download is retried. Never blindly retry a sent message.
                            for attempt in range(1, cfg.attempts + 1):
                                attempt_dir = work / f"attempt-{attempt}"
                                attempt_dir.mkdir()
                                try:
                                    job.phase = f"resolving (attempt {attempt}/{cfg.attempts})"
                                    async with resolver.resolve(job.mal, job.language, episode) as stream:
                                        job.phase = "downloading / processing subtitles"
                                        source, note = await download(
                                            stream, attempt_dir, job.language, quality=cfg.quality,
                                            subtitle_mode=cfg.subtitle_mode, max_bytes=cfg.max_temp_bytes,
                                            timeout=cfg.operation_timeout)
                                    break
                                except asyncio.CancelledError:
                                    raise
                                except Exception:
                                    self.save_process_log(attempt_dir, job)
                                    if attempt == cfg.attempts:
                                        raise
                                    log.exception("Episode %s download attempt %s failed", episode, attempt)
                                    shutil.rmtree(attempt_dir)
                                    await asyncio.sleep(3)
                            job.phase = "checking whole-video size"
                            check_upload_size(source, limit)
                            if note:
                                # Keep each episode's video caption in the exact requested format.
                                log.warning("%s episode %s: %s", job.title, episode, note)
                                await ctx.send(f"Subtitle warning for episode {episode}: {note}")
                                await asyncio.sleep(cfg.delay)
                            job.phase = "uploading whole episode"
                            filename = f"MAL-{job.mal}_EP-{episode:04d}_{job.language}.mp4"
                            attachment = discord.File(str(source), filename=filename)
                            try:
                                message = await target.send(episode_caption(job.title, episode), file=attachment)
                            finally:
                                attachment.close()
                            # The episode is complete only after its single attachment is accepted.
                            self.state.mark(key, [message.id])
                            job.sent += 1
                            delay = max(cfg.delay, getattr(target, "slowmode_delay", 0))
                            await asyncio.sleep(delay)
                            failures_in_a_row = 0
                        except asyncio.CancelledError:
                            raise
                        except UploadTooLarge as exc:
                            job.failed += 1
                            job.phase = "stopped: whole episode exceeds upload cap"
                            await ctx.send(f"Episode {episode}: {exc}")
                            return
                        except discord.HTTPException as exc:
                            # Stop on permissions/upload failures, including 413; do not flood retries.
                            job.failed += 1
                            job.phase = f"stopped: Discord HTTP {exc.status}"
                            log.exception("Discord upload failed")
                            await ctx.send(f"Stopped at EP {episode}: Discord HTTP {exc.status}. "
                                           "Discord enforces your actual account limit; UPLOAD_LIMIT_MB does not change it. "
                                           "No splitting was performed and this episode was not checkpointed.")
                            return
                        except Exception:
                            job.failed += 1
                            failures_in_a_row += 1
                            log.exception("Episode %s failed", episode)
                            for folder in work.glob("attempt-*"):
                                self.save_process_log(folder, job)
                            await ctx.send(f"EP {episode} failed; see local logs. Continuing unless "
                                           f"{cfg.max_consecutive_failures} consecutive episodes fail.")
                            if failures_in_a_row >= cfg.max_consecutive_failures:
                                job.phase = "stopped: consecutive source/media failures"
                                await ctx.send(job.text())
                                return
            job.phase = "finished"
            await ctx.send(job.text())
        except TitleError as exc:
            job.phase = "stopped: anime title lookup failed"
            log.warning("Title lookup failed: %s", exc)
            await ctx.send(str(exc))
        except asyncio.CancelledError:
            job.phase = "cancelled"
            with contextlib.suppress(Exception):
                await ctx.send("Cancelled. Completed episodes remain checkpointed.\n" + job.text())
        except Exception:
            job.phase = "stopped: setup or unexpected error"
            log.exception("Job stopped")
            with contextlib.suppress(Exception):
                await ctx.send("Job stopped. See logs/bot.log.\n" + job.text())

    @staticmethod
    def save_process_log(folder: Path, job: Job):
        source = folder / "process.log"
        if source.exists():
            destination = ROOT / "logs" / f"last-error-{job.mal}-{job.language}.log"
            destination.parent.mkdir(exist_ok=True)
            shutil.copyfile(source, destination)
            destination.chmod(0o600)

    async def close(self):
        if self.worker and not self.worker.done():
            self.worker.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self.worker
        await super().close()


def main():
    load_dotenv(ROOT / ".env")
    for name in ("ffmpeg", "ffprobe"):
        if not shutil.which(name):
            raise SystemExit(f"Missing {name}. Install FFmpeg and add its bin directory to PATH.")
    token = os.getenv("DISCORD_TOKEN", "").strip()
    if not token or token == "YOUR_USER_TOKEN_HERE":
        raise SystemExit("Set DISCORD_TOKEN locally in .env. Never send it in chat or commit it.")
    (ROOT / "logs").mkdir(exist_ok=True)
    handler = RotatingFileHandler(ROOT / "logs" / "bot.log", maxBytes=2 * MIB, backupCount=3)
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
    logging.basicConfig(level=logging.INFO, handlers=[handler, logging.StreamHandler()])
    settings = Settings.from_env()
    bot = MegaPlayBot(settings, State(ROOT / "state.json"))
    bot.run(token, log_handler=None)


if __name__ == "__main__":
    main()
